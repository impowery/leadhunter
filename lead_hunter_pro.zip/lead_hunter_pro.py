#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lead Hunter Pro — Поиск клиентов + Telegram-интеграция
Без API-ключей job boards. Без n8n. Без подписок.

Установка:
  pip install requests telethon python-telegram-bot

Настройка:
  1. Создай .env файл
  2. Запусти авторизацию: python lead_hunter_pro.py --auth
  3. Запускай: python lead_hunter_pro.py
"""

import os
import sys
import sqlite3
import re
import hashlib
import csv
import time
import random
import asyncio
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass
from typing import List

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    print("Install: pip install requests")
    sys.exit(1)

try:
    from telethon import TelegramClient
    HAS_TELETHON = True
except ImportError:
    HAS_TELETHON = False
    print("Telethon not installed. TG channels skipped.")

try:
    from telegram import Bot
    HAS_PTBBOT = True
except ImportError:
    HAS_PTBBOT = False
    print("python-telegram-bot not installed. Notifications skipped.")

# ─── КОНФИГУРАЦИЯ ─────────────────────────────────────────────────

KEYWORDS = [
    "AI agent", "n8n", "automation", "workflow automation",
    "scraping", "web scraping", "data extraction",
    "LLM", "chatbot", "AI assistant", "GPT",
    "integration", "Zapier", "Make.com",
    "Python", "API", "backend", "full stack",
    "process automation", "data pipeline", "ETL",
    "freelance", "contract", "remote", "part-time",
    "founding engineer", "early employee", "co-founder",
    "consultant", "advisor", "SaaS", "startup", "MVP",
    "no-code", "low-code", "internal tool",
    "web3", "crypto", "blockchain", "defi",
]

EXCLUDE = []

TELEGRAM_CHANNELS = [
    "web3_jobs_crypto_vazima", "jobstash", "workingincrypto",
    "cryptoheadhunter", "opento_crypto", "web30job",
    "cryptovakansii", "the_workys", "xCareers",
]

DB_PATH = Path("leads.db")
REPORT_PATH = Path("leads_report.html")
CSV_PATH = Path("leads.csv")
SESSION_NAME = "lead_hunter_session"

MIN_SCORE = 2.0
TELEGRAM_NOTIFY_SCORE = 5.0
DELAY_MIN = 1.0
DELAY_MAX = 3.0
REQUEST_TIMEOUT = 10

TELEGRAM_API_ID = int(os.getenv("TELEGRAM_API_ID", "0"))
TELEGRAM_API_HASH = os.getenv("TELEGRAM_API_HASH", "")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# ─── DATA CLASS ───────────────────────────────────────────────────

@dataclass
class Lead:
    id: str
    title: str
    company: str
    description: str
    url: str
    source: str
    posted_date: str
    matched_keywords: List[str]
    score: float
    found_at: str = ""
    is_new: bool = False

# ─── БАЗА ДАННЫХ ──────────────────────────────────────────────────

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS leads (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, company TEXT,
            description TEXT, url TEXT NOT NULL, source TEXT NOT NULL,
            posted_date TEXT, matched_keywords TEXT, score REAL DEFAULT 0,
            found_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, contacted INTEGER DEFAULT 0,
            notes TEXT, notified INTEGER DEFAULT 0
        )
    """)
    c.execute("CREATE INDEX IF NOT EXISTS idx_source ON leads(source)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_score ON leads(score)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_found_at ON leads(found_at)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_notified ON leads(notified)")
    conn.commit()
    conn.close()

def lead_exists(lead_id: str) -> bool:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT 1 FROM leads WHERE id = ?", (lead_id,))
    result = c.fetchone() is not None
    conn.close()
    return result

def save_lead(lead: Lead) -> bool:
    if lead_exists(lead.id):
        return False
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO leads (id, title, company, description, url, source, posted_date, matched_keywords, score, found_at, notified)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        lead.id, lead.title, lead.company, lead.description, lead.url,
        lead.source, lead.posted_date, ",".join(lead.matched_keywords),
        lead.score, lead.found_at or datetime.now().isoformat(),
        1 if lead.score >= TELEGRAM_NOTIFY_SCORE else 0
    ))
    conn.commit()
    conn.close()
    return True

def get_all_leads() -> List[Lead]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM leads ORDER BY score DESC, found_at DESC")
    rows = c.fetchall()
    conn.close()
    result = []
    for r in rows:
        mk = r.get("matched_keywords", "")
        keywords = mk.split(",") if mk else []
        result.append(Lead(
            id=r["id"], title=r["title"], company=r.get("company", ""),
            description=r.get("description", ""), url=r["url"], source=r["source"],
            posted_date=r.get("posted_date", ""), matched_keywords=keywords,
            score=r.get("score", 0), found_at=r.get("found_at", "")
        ))
    return result

def get_stats() -> dict:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM leads")
    total = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM leads WHERE date(found_at) = date('now')")
    today = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM leads WHERE contacted = 1")
    contacted = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM leads WHERE notified = 0 AND score >= ?", (TELEGRAM_NOTIFY_SCORE,))
    not_notified = c.fetchone()[0]
    c.execute("SELECT source, COUNT(*) FROM leads GROUP BY source")
    by_source = dict(c.fetchall())
    conn.close()
    return {"total": total, "today": today, "contacted": contacted, "not_notified": not_notified, "by_source": by_source}

def mark_notified(lead_id: str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE leads SET notified = 1 WHERE id = ?", (lead_id,))
    conn.commit()
    conn.close()

# ─── СКОРИНГ ──────────────────────────────────────────────────────

def score_text(text: str) -> tuple:
    text_lower = text.lower()
    matched = [kw for kw in KEYWORDS if kw.lower() in text_lower]
    excluded = [ex for ex in EXCLUDE if ex.lower() in text_lower]
    score = len(matched) * 2.0
    if "remote" in text_lower and any(k in text_lower for k in ["ai", "automation", "n8n", "llm", "web3", "crypto"]):
        score += 3
    if any(w in text_lower for w in ["freelance", "contract", "consultant"]):
        score += 2
    if any(w in text_lower for w in ["founding", "early employee", "co-founder"]):
        score += 2
    if "$" in text and re.search(r"\$\d+[\d,]*[kK]?", text):
        score += 1
    if "equity" in text_lower:
        score += 1
    if any(w in text_lower for w in ["urgent", "asap", "immediate"]):
        score += 1
    score -= len(excluded) * 1.5
    return max(0.0, round(score, 1)), matched

def make_id(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:16]

# ─── HTTP ─────────────────────────────────────────────────────────

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36",
]

def fetch_json(url: str, timeout: int = REQUEST_TIMEOUT) -> dict:
    try:
        time.sleep(random.uniform(DELAY_MIN, DELAY_MAX))
        resp = requests.get(url, headers={"User-Agent": random.choice(USER_AGENTS)}, timeout=timeout)
        if resp.status_code == 200:
            return resp.json()
    except Exception as e:
        print(f"      Fetch error: {e}")
    return {}

# ─── ПАРСЕРЫ ──────────────────────────────────────────────────────

def parse_hn_hiring() -> List[Lead]:
    leads = []
    try:
        data = fetch_json("https://hn.algolia.com/api/v1/search?query=Ask+HN+Who+is+hiring&tags=story&hitsPerPage=2", timeout=8)
        for hit in data.get("hits", []):
            if "who is hiring" not in hit.get("title", "").lower():
                continue
            post_id = hit["objectID"]
            comments = fetch_json(f"https://hn.algolia.com/api/v1/search?tags=comment,story_{post_id}&hitsPerPage=200", timeout=10)
            for comment in comments.get("hits", []):
                text = comment.get("text", "")
                if not text or len(text) < 80:
                    continue
                text = re.sub(r"<[^>]+>", " ", text)
                score, matched = score_text(text)
                if score >= MIN_SCORE and matched:
                    lines = [l.strip() for l in text.split("\n") if l.strip()]
                    title = lines[0][:120] if lines else "Job posting"
                    company = title.split("|")[0].strip()[:50] if "|" in title else ""
                    lead_id = make_id(comment["objectID"])
                    if not lead_exists(lead_id):
                        leads.append(Lead(
                            id=lead_id, title=title, company=company,
                            description=text[:1000],
                            url=f"https://news.ycombinator.com/item?id={comment['objectID']}",
                            source="Hacker News",
                            posted_date=datetime.fromtimestamp(comment.get("created_at_i", 0)).strftime("%Y-%m-%d"),
                            score=score, matched_keywords=matched
                        ))
    except Exception as e:
        print(f"      HN error: {e}")
    return leads

def parse_reddit_forhire() -> List[Lead]:
    leads = []
    try:
        url = "https://www.reddit.com/r/forhire/search.json?q=automation+OR+n8n+OR+chatbot&sort=new&limit=20"
        data = fetch_json(url, timeout=5)
        for post in data.get("data", {}).get("children", []):
            p = post["data"]
            title = p.get("title", "").replace("&amp;", "&")
            text = p.get("selftext", "").replace("&amp;", "&")
            if not title.startswith("[Hiring]"):
                continue
            score, matched = score_text(f"{title} {text}")
            if score >= MIN_SCORE and matched:
                lead_id = make_id(p.get("permalink", ""))
                if not lead_exists(lead_id):
                    leads.append(Lead(
                        id=lead_id, title=title[:120],
                        company=f"u/{p.get('author', 'unknown')}",
                        description=text[:800],
                        url=f"https://reddit.com{p.get('permalink', '')}",
                        source="Reddit r/forhire",
                        posted_date=datetime.fromtimestamp(p.get("created_utc", 0)).strftime("%Y-%m-%d"),
                        score=score, matched_keywords=matched
                    ))
    except Exception as e:
        print(f"      Reddit forhire error: {e}")
    return leads

def parse_reddit_freelance() -> List[Lead]:
    leads = []
    try:
        url = "https://www.reddit.com/r/freelance/search.json?q=hire+automation&sort=new&limit=20"
        data = fetch_json(url, timeout=5)
        signals = ["hiring", "looking for", "need a", "seeking", "want to hire"]
        for post in data.get("data", {}).get("children", []):
            p = post["data"]
            title = p.get("title", "").replace("&amp;", "&")
            text = p.get("selftext", "").replace("&amp;", "&")
            if not any(s in title.lower() for s in signals):
                continue
            score, matched = score_text(f"{title} {text}")
            if score >= MIN_SCORE - 0.5:
                lead_id = make_id(p.get("permalink", ""))
                if not lead_exists(lead_id):
                    leads.append(Lead(
                        id=lead_id, title=title[:120],
                        company=f"u/{p.get('author', 'unknown')}",
                        description=text[:800],
                        url=f"https://reddit.com{p.get('permalink', '')}",
                        source="Reddit r/freelance",
                        posted_date=datetime.fromtimestamp(p.get("created_utc", 0)).strftime("%Y-%m-%d"),
                        score=score, matched_keywords=matched
                    ))
    except Exception as e:
        print(f"      Reddit freelance error: {e}")
    return leads

# ─── TELEGRAM ─────────────────────────────────────────────────────

async def parse_telegram_channels() -> List[Lead]:
    leads = []
    if not HAS_TELETHON or not TELEGRAM_API_ID or not TELEGRAM_API_HASH:
        print("      Telegram: Telethon not configured")
        return leads
    client = TelegramClient(SESSION_NAME, TELEGRAM_API_ID, TELEGRAM_API_HASH)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            print("      Telegram: Not authorized. Run: python lead_hunter_pro.py --auth")
            await client.disconnect()
            return leads
        for channel_name in TELEGRAM_CHANNELS:
            try:
                print(f"      Parsing @{channel_name}...")
                entity = await client.get_entity(channel_name)
                messages = await client.get_messages(entity, limit=50)
                for msg in messages:
                    if not msg.text:
                        continue
                    text = msg.text
                    score, matched = score_text(text)
                    if score >= MIN_SCORE and matched:
                        if hasattr(entity, "username") and entity.username:
                            msg_url = f"https://t.me/{entity.username}/{msg.id}"
                        else:
                            msg_url = f"https://t.me/c/{entity.id}/{msg.id}"
                        lead_id = make_id(f"{channel_name}_{msg.id}")
                        if not lead_exists(lead_id):
                            lines = [l.strip() for l in text.split("\n") if l.strip()]
                            title = lines[0][:120] if lines else "Telegram post"
                            posted = msg.date.strftime("%Y-%m-%d") if msg.date else ""
                            leads.append(Lead(
                                id=lead_id, title=title,
                                company=f"@{channel_name}",
                                description=text[:1000],
                                url=msg_url,
                                source=f"TG @{channel_name}",
                                posted_date=posted,
                                score=score, matched_keywords=matched
                            ))
                count = len([l for l in leads if l.source == f"TG @{channel_name}"])
                print(f"         Found: {count}")
            except Exception as e:
                print(f"         @{channel_name}: {e}")
            time.sleep(random.uniform(1, 2))
    except Exception as e:
        print(f"      Telegram error: {e}")
    finally:
        await client.disconnect()
    return leads

async def auth_telegram():
    if not HAS_TELETHON:
        print("Install Telethon: pip install telethon")
        return
    if not TELEGRAM_API_ID or not TELEGRAM_API_HASH:
        print("Set TELEGRAM_API_ID and TELEGRAM_API_HASH in .env")
        return
    client = TelegramClient(SESSION_NAME, TELEGRAM_API_ID, TELEGRAM_API_HASH)
    await client.start()
    print("Auth successful! Session saved.")
    await client.disconnect()

# ─── УВЕДОМЛЕНИЯ ─────────────────────────────────────────────────

async def send_telegram_notification(lead: Lead):
    if not HAS_PTBBOT or not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return False
    try:
        bot = Bot(token=TELEGRAM_BOT_TOKEN)
        keywords_str = ", ".join(lead.matched_keywords[:5])
        message = (
            f"🎯 <b>New Lead (Score: {lead.score})</b>\n\n"
            f"<b>{lead.title}</b>\n"
            f"🏢 {lead.company}\n"
            f"📡 {lead.source}\n"
            f"📅 {lead.posted_date}\n\n"
            f"🔑 Keywords: {keywords_str}\n\n"
            f"{lead.description[:300]}{'...' if len(lead.description) > 300 else ''}\n\n"
            f"🔗 <a href='{lead.url}'>Open</a>"
        )
        await bot.send_message(
            chat_id=TELEGRAM_CHAT_ID,
            text=message,
            parse_mode="HTML",
            disable_web_page_preview=False
        )
        return True
    except Exception as e:
        print(f"      TG notify error: {e}")
        return False

# ─── ОТЧЁТЫ ──────────────────────────────────────────────────────

def generate_html_report(leads: List[Lead], stats: dict):
    new_count = sum(1 for l in leads if l.is_new)
    total = len(leads)
    source_counts = {}
    for l in leads:
        src = l.source
        source_counts[src] = source_counts.get(src, 0) + 1

    def esc(s):
        return str(s).replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

    html = "<!DOCTYPE html>\n<html lang='ru'><head><meta charset='UTF-8'>"
    html += "<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
    html += f"<title>Lead Hunter Pro — {datetime.now().strftime('%Y-%m-%d %H:%M')}</title>"
    html += "<style>"
    html += ":root{--bg:#0a0a0f;--card:#12121a;--border:#1e1e2e;--text:#e2e8f0;--muted:#94a3b8;--accent:#60a5fa;--success:#34d399;--warning:#fbbf24;--danger:#f87171;}"
    html += "*{margin:0;padding:0;box-sizing:border-box;}body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--bg);color:var(--text);line-height:1.6;}"
    html += ".container{max-width:1200px;margin:0 auto;padding:2rem;}.header{background:linear-gradient(135deg,#1e3a5f 0%,var(--bg) 100%);padding:2.5rem;border-radius:20px;margin-bottom:2rem;border:1px solid var(--border);}"
    html += ".header h1{font-size:2.2rem;margin-bottom:0.5rem;color:var(--accent);}.header p{color:var(--muted);}"
    html += ".stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin-bottom:2rem;}"
    html += ".stat-card{background:var(--card);padding:1.5rem;border-radius:16px;border:1px solid var(--border);text-align:center;}"
    html += ".stat-number{font-size:2.2rem;font-weight:700;}.stat-number.total{color:var(--accent);}.stat-number.new{color:var(--success);}.stat-number.contacted{color:var(--warning);}"
    html += ".stat-label{color:var(--muted);font-size:0.85rem;margin-top:0.25rem;}"
    html += ".filters{display:flex;gap:1rem;margin-bottom:1.5rem;flex-wrap:wrap;}"
    html += ".filter-btn{background:var(--card);border:1px solid var(--border);color:var(--text);padding:0.5rem 1rem;border-radius:8px;cursor:pointer;font-size:0.9rem;}"
    html += ".filter-btn:hover,.filter-btn.active{background:var(--accent);color:var(--bg);border-color:var(--accent);}"
    html += ".lead-card{background:var(--card);border-radius:16px;padding:1.5rem;margin-bottom:1rem;border:1px solid var(--border);transition:all 0.3s;}"
    html += ".lead-card:hover{border-color:var(--accent);transform:translateX(4px);box-shadow:0 4px 20px rgba(96,165,250,0.1);}"
    html += ".lead-card.new{border-left:3px solid var(--success);}.lead-card.seen{border-left:3px solid var(--border);opacity:0.85;}"
    html += ".lead-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:0.75rem;gap:1rem;}"
    html += ".lead-title{font-size:1.15rem;font-weight:600;color:var(--text);text-decoration:none;line-height:1.4;}"
    html += ".lead-title:hover{color:var(--accent);}.lead-meta{display:flex;gap:1.25rem;flex-wrap:wrap;margin-bottom:0.75rem;font-size:0.85rem;color:var(--muted);}"
    html += ".badge{display:inline-block;padding:0.3rem 0.8rem;border-radius:20px;font-size:0.75rem;font-weight:600;white-space:nowrap;}"
    html += ".badge-new{background:rgba(52,211,153,0.15);color:var(--success);}.badge-seen{background:rgba(148,163,184,0.15);color:var(--muted);}"
    html += ".badge-hn{background:rgba(124,58,237,0.15);color:#a78bfa;}.badge-reddit{background:rgba(234,88,12,0.15);color:#fdba74;}"
    html += ".badge-tg{background:rgba(59,130,246,0.15);color:#93c5fd;}"
    html += ".score{font-size:1.4rem;font-weight:700;min-width:40px;text-align:center;}"
    html += ".keywords{display:flex;flex-wrap:wrap;gap:0.5rem;margin-top:0.75rem;}"
    html += ".keyword{background:rgba(96,165,250,0.1);color:var(--accent);padding:0.25rem 0.7rem;border-radius:6px;font-size:0.8rem;border:1px solid rgba(96,165,250,0.2);}"
    html += ".description{color:#cbd5e1;font-size:0.9rem;margin-top:0.5rem;line-height:1.6;}"
    html += ".actions{display:flex;gap:0.75rem;margin-top:1rem;}"
    html += ".action-btn{background:transparent;border:1px solid var(--border);color:var(--muted);padding:0.4rem 0.8rem;border-radius:6px;font-size:0.8rem;cursor:pointer;transition:all 0.2s;text-decoration:none;display:inline-flex;align-items:center;gap:0.3rem;}"
    html += ".action-btn:hover{border-color:var(--accent);color:var(--accent);}"
    html += ".empty{text-align:center;padding:4rem;color:var(--muted);}"
    html += ".footer{text-align:center;margin-top:3rem;padding:2rem;color:var(--muted);font-size:0.85rem;border-top:1px solid var(--border);}"
    html += "@media(max-width:768px){.container{padding:1rem;}.header h1{font-size:1.5rem;}.lead-header{flex-direction:column;}}"
    html += "</style></head><body><div class='container'>"

    html += f"<div class='header'><h1>🔍 Lead Hunter Pro</h1><p>Автоматический поиск клиентов, проектов и возможностей</p><p style='margin-top:0.5rem;font-size:0.85rem'>📅 {datetime.now().strftime('%Y-%m-%d %H:%M')} | 💾 {total} лидов | 🆕 {new_count} новых | ✅ {stats['contacted']} контактов | 📨 {stats['not_notified']} неотправлено</p></div>"
    html += "<div class='stats'>"
    html += f"<div class='stat-card'><div class='stat-number total'>{total}</div><div class='stat-label'>Всего в базе</div></div>"
    html += f"<div class='stat-card'><div class='stat-number new'>{new_count}</div><div class='stat-label'>Новых сегодня</div></div>"
    html += f"<div class='stat-card'><div class='stat-number contacted'>{stats['contacted']}</div><div class='stat-label'>Контактов</div></div>"
    html += f"<div class='stat-card'><div class='stat-number' style='color:var(--accent)'>{len(KEYWORDS)}</div><div class='stat-label'>Ключевых слов</div></div>"
    html += f"<div class='stat-card'><div class='stat-number' style='color:var(--warning)'>{len(source_counts)}</div><div class='stat-label'>Источников</div></div>"
    html += "</div>"
    html += "<div class='filters'><button class='filter-btn active' onclick=\"filterLeads('all')\">Все</button><button class='filter-btn' onclick=\"filterLeads('new')\">Только новые</button><button class='filter-btn' onclick=\"filterLeads('hn')\">Hacker News</button><button class='filter-btn' onclick=\"filterLeads('reddit')\">Reddit</button><button class='filter-btn' onclick=\"filterLeads('tg')\">Telegram</button><button class='filter-btn' onclick=\"filterLeads('high')\">Score 5+</button></div>"

    if not leads:
        html += "<div class='empty'><h2>🔍 Пока ничего не найдено</h2><p>Попробуйте расширить ключевые слова или запустить позже</p></div>"
    else:
        for lead in leads:
            is_new = lead.is_new
            card_class = "new" if is_new else "seen"
            badge_class = "badge-new" if is_new else "badge-seen"
            badge_text = "NEW" if is_new else "SEEN"
            src = lead.source.lower().replace(" ", "-").replace("/", "").replace("@", "")
            source_badge = f"badge-{src}"
            score_color = "var(--success)" if lead.score >= 5 else "var(--warning)" if lead.score >= 3 else "var(--muted)"
            desc = esc(lead.description[:350])
            if len(lead.description) > 350:
                desc += "..."
            keywords_html = "".join(f'<span class="keyword">{esc(k.strip())}</span>' for k in lead.matched_keywords if k.strip())
            html += f'<div class="lead-card {card_class}" data-source="{src}" data-new="{str(is_new).lower()}" data-score="{lead.score}"><div class="lead-header"><div style="flex:1"><a href="{esc(lead.url)}" target="_blank" class="lead-title">{esc(lead.title)}</a><div class="lead-meta"><span>🏢 {esc(lead.company)}</span><span>📅 {esc(lead.posted_date)}</span><span>📡 {esc(lead.source)}</span></div></div><div style="display:flex;gap:0.5rem;align-items:center;flex-shrink:0"><span class="badge {source_badge}">{esc(lead.source)}</span><span class="badge {badge_class}">{badge_text}</span><span class="score" style="color:{score_color}">{lead.score}</span></div></div><div class="description">{desc}</div><div class="keywords">{keywords_html}</div><div class="actions"><a href="{esc(lead.url)}" target="_blank" class="action-btn">🔗 Открыть</a></div></div>'

    html += "<div class='footer'><p>🚀 Lead Hunter Pro — полностью бесплатно • Без API-ключей job boards • Без n8n • Без подписок</p><p style='margin-top:0.5rem'>Запускай раз в день через cron/планировщик задач</p></div></div>"
    html += "<script>function filterLeads(type){document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));event.target.classList.add('active');document.querySelectorAll('.lead-card').forEach(card=>{let show=true;if(type==='new')show=card.dataset.new==='true';else if(type==='hn')show=card.dataset.source.includes('hacker');else if(type==='reddit')show=card.dataset.source.includes('reddit');else if(type==='tg')show=card.dataset.source.includes('tg')||card.dataset.source.includes('telegram');else if(type==='high')show=parseFloat(card.dataset.score)>=5;card.style.display=show?'block':'none';});}</script></body></html>"

    REPORT_PATH.write_text(html, encoding="utf-8")
    return REPORT_PATH

def export_csv(leads: List[Lead]):
    with open(CSV_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["title","company","source","score","url","posted_date","matched_keywords","description","found_at"])
        writer.writeheader()
        for lead in leads:
            writer.writerow({
                "title": lead.title, "company": lead.company,
                "source": lead.source, "score": lead.score,
                "url": lead.url, "posted_date": lead.posted_date,
                "matched_keywords": ",".join(lead.matched_keywords),
                "description": lead.description, "found_at": lead.found_at
            })
    return CSV_PATH

# ─── ГЛАВНЫЙ ПОТОК ───────────────────────────────────────────────

async def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--auth":
        await auth_telegram()
        return
    print("=" * 60)
    print("🚀  LEAD HUNTER PRO")
    print("   Бесплатный поиск клиентов + Telegram-интеграция")
    print("=" * 60)
    init_db()
    all_new_leads = []
    sources = [
        ("Hacker News", parse_hn_hiring),
        ("Reddit r/forhire", parse_reddit_forhire),
        ("Reddit r/freelance", parse_reddit_freelance),
    ]
    for name, parser in sources:
        print(f"\n📡  {name}...")
        try:
            leads = parser()
            new_count = 0
            for lead in leads:
                if save_lead(lead):
                    lead.is_new = True
                    new_count += 1
                    all_new_leads.append(lead)
                else:
                    lead.is_new = False
            print(f"   ✅  Найдено: {len(leads)} | Новых: {new_count}")
        except Exception as e:
            print(f"   ❌  Ошибка: {e}")
    if HAS_TELETHON and TELEGRAM_API_ID and TELEGRAM_API_HASH:
        print("\n📡  Telegram-каналы...")
        try:
            tg_leads = await parse_telegram_channels()
            new_count = 0
            for lead in tg_leads:
                if save_lead(lead):
                    lead.is_new = True
                    new_count += 1
                    all_new_leads.append(lead)
                else:
                    lead.is_new = False
            print(f"   ✅  Найдено: {len(tg_leads)} | Новых: {new_count}")
        except Exception as e:
            print(f"   ❌  Ошибка: {e}")
    else:
        print("\n📡  Telegram-каналы... Пропущено (не настроен Telethon)")
    all_leads = get_all_leads()
    new_ids = {l.id for l in all_new_leads}
    for lead in all_leads:
        lead.is_new = lead.id in new_ids
    stats = get_stats()
    print(f"\n{'=' * 60}")
    print(f"📊  ИТОГИ: {len(all_new_leads)} новых | {stats['total']} всего")
    print(f"   По источникам: {stats['by_source']}")
    if HAS_PTBBOT and TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
        print(f"\n📨  Отправка уведомлений в Telegram...")
        notified_count = 0
        for lead in all_new_leads:
            if lead.score >= TELEGRAM_NOTIFY_SCORE:
                success = await send_telegram_notification(lead)
                if success:
                    mark_notified(lead.id)
                    notified_count += 1
                    print(f"   ✅  Отправлено: {lead.title[:50]}...")
        print(f"   📨  Отправлено уведомлений: {notified_count}")
    else:
        print(f"\n📨  Telegram-уведомления: Не настроены")
    report_path = generate_html_report(all_leads, stats)
    csv_path = export_csv(all_leads)
    print(f"\n📄  HTML: {report_path.absolute()}")
    print(f"📄  CSV:  {csv_path.absolute()}")
    print(f"🗄️   DB:   {DB_PATH.absolute()}")
    print("=" * 60)
    return all_new_leads, all_leads

if __name__ == "__main__":
    asyncio.run(main())
