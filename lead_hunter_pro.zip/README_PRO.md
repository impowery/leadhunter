# 🔍 Lead Hunter Pro

**Бесплатный поиск клиентов + Telegram-интеграция.**
Без API-ключей job boards. Без n8n. Без подписок.

---

## 🚀 Быстрый старт

### 1. Установи зависимости
```bash
pip install requests telethon python-telegram-bot
```

### 2. Настрой переменные окружения
```bash
cp .env.example .env
nano .env  # заполни своими данными
```

### 3. Авторизуй Telethon (один раз)
```bash
python lead_hunter_pro.py --auth
# Введи номер телефона и код из Telegram
```

### 4. Запусти
```bash
python lead_hunter_pro.py
```

---

## 📋 Что делает

| Источник | Метод | Что ищет |
|----------|-------|----------|
| **Hacker News** | Algolia API (бесплатно) | Tech-вакансии, founding engineer |
| **Reddit r/forhire** | JSON API (бесплатно) | Фриланс, контракты |
| **Reddit r/freelance** | JSON API (бесплатно) | Клиенты ищут исполнителей |
| **9 Telegram-каналов** | Telethon (MTProto) | Web3, crypto, AI вакансии |

**Вывод:**
- `leads_report.html` — красивый отчёт с фильтрами
- `leads.csv` — для импорта в CRM
- `leads.db` — SQLite база (история + дедупликация)
- **Telegram-уведомления** — мгновенные алерты о лидах score 5+

---

## 🔧 Настройка ключевых слов

Открой `lead_hunter_pro.py`, найди раздел `KEYWORDS`:

```python
KEYWORDS = [
    # Твоя экспертиза (из LinkedIn/X)
    "AI agent", "n8n", "automation", "workflow automation",
    "scraping", "web scraping", "data extraction",
    "LLM", "chatbot", "AI assistant", "GPT",

    # Технологии
    "Python", "API", "backend", "full stack",
    "process automation", "data pipeline", "ETL",

    # Тип сделки
    "freelance", "contract", "remote", "part-time",
    "founding engineer", "early employee", "co-founder",
    "consultant", "advisor",

    # Дополнительно (для крипто-каналов)
    "web3", "crypto", "blockchain", "defi",
]
```

---

## 📡 Telegram-каналы (преднастроены)

```python
TELEGRAM_CHANNELS = [
    "web3_jobs_crypto_vazima",
    "jobstash",
    "workingincrypto",
    "cryptoheadhunter",
    "opento_crypto",
    "web30job",
    "cryptovakansii",
    "the_workys",
    "xCareers",
]
```

Добавь свои — просто впиши username канала.

---

## 🔐 Получение Telegram API credentials

### 1. API_ID и API_HASH (для парсинга каналов)
1. Зайди на https://my.telegram.org/apps
2. Войди в свой аккаунт Telegram
3. Заполни форму:
   - App title: `Lead Hunter`
   - Short name: `lead_hunter`
   - Platform: `Desktop`
4. Получи `api_id` и `api_hash`
5. Запиши в `.env`

### 2. BOT_TOKEN (для уведомлений)
1. Напиши @BotFather в Telegram
2. `/newbot` → назови бота → получи токен
3. Запиши в `.env`

### 3. CHAT_ID (куда слать уведомления)
**Вариант A — личные сообщения:**
1. Напиши своему боту `/start`
2. Открой в браузере: `https://api.telegram.org/bot<TOKEN>/getUpdates`
3. Найди `"chat":{"id":123456789` — это твой CHAT_ID

**Вариант B — группа:**
1. Добавь бота в группу
2. Отправь сообщение в группу
3. Открой тот же URL
4. Найди `"chat":{"id":-123456789` (с минусом — это группа)

---

## ⏰ Автозапуск

### Linux/Mac (cron)
```bash
crontab -e
# Каждый день в 9:00
0 9 * * * cd /path/to/lead_hunter && python lead_hunter_pro.py >> cron.log 2>&1
```

### Windows (Планировщик задач)
1. Создать задачу → Ежедневно → 9:00
2. Действие: `python.exe lead_hunter_pro.py`
3. Начать в: `C:\path\to\lead_hunter`

---

## 🏗️ Архитектура

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Hacker News    │     │                 │     │  HTML-отчёт     │
│  Reddit         │────▶│  Lead Hunter    │────▶│  CSV            │
│  Telegram (9    │     │  (Python)       │     │  SQLite DB      │
│   каналов)      │     │                 │     │  TG-уведомления │
└─────────────────┘     │  ┌───────────┐  │     └─────────────────┘
                        │  │ Парсер    │  │
                        │  │ Скоринг   │  │
                        │  │ Дедуплика │  │
                        │  │ Фильтр    │  │
                        │  └───────────┘  │
                        │                 │
                        │  ┌───────────┐  │
                        │  │ Scheduler │  │
                        │  │ (cron)    │  │
                        │  └───────────┘  │
                        └─────────────────┘
```

---

## 📊 Сравнение с n8n-решением

| | **Lead Hunter Pro** | **n8n-решение** |
|---|---|---|
| **Стоимость** | **$0** | $20-200/мес |
| **API ключи** | **Только TG (бесплатно)** | 4 платных job board API |
| **Инфраструктура** | **Python файл** | n8n + Sheets + 4 API |
| **Telegram** | **Встроен** | Нужен отдельный бот |
| **Telegram-каналы** | **9 каналов из коробки** | Нет |
| **Приватность** | **Локально** | Облако |
| **Надёжность** | **Твой код** | 5+ точек отказа |

---

## ⚠️ Ограничения

| Проблема | Решение |
|----------|---------|
| Reddit блокирует | Увеличь `DELAY_MAX`, используй прокси |
| HN обновляется раз в месяц | Дополняй другими источниками |
| TG rate limits | Telethon обрабатывает автоматически |
| Нужен номер телефона | Только для первой авторизации |

---

## 💡 Советы

1. **Score 7+** — обязательно откликайся
2. **Score 5-6** — стоит посмотреть
3. **Запускай утром** — свежие посты появляются ночью (US timezone)
4. **Добавляй каналы** — чем больше источников, тем больше лидов
5. **Настрой EXCLUDE** — фильтруй нерелевантное

---

**Лицензия:** MIT
